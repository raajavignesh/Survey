import { Component, OnInit, ViewChild } from "@angular/core";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
  FormArray
} from "@angular/forms";

@Component({
  selector: "app-create-survey",
  templateUrl: "./create-survey.component.html",
  styleUrls: ["./create-survey.component.css"]
})
export class CreateSurveyComponent implements OnInit {
  public survey: any = {};
  public questions: any[] = [];

  surveyForm: FormGroup;
  surveyFormSubmit: boolean;

  questionForm: FormGroup;

  smallText: boolean;
  largeText: boolean;
  normalChoice: boolean;
  imageChoice: boolean;
  yesNo: boolean;
  radio: boolean;
  minval: any;
  addOptionRemove: boolean;
  addQuestionRemove: boolean;
  surveyCreationCompleted: boolean;
  enableNext: boolean;

  fileName: String;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.surveyForm = this.formBuilder.group({
      surveyName: ["", Validators.required],
      description: ["", Validators.required],
      creationTime: [new Date().toISOString().slice(0, 16)],
      start: [""],
      end: [""],
      questions: this.formBuilder.array([])
    });

    var today = new Date().toISOString().slice(0, 16);
    this.minval = today;

    this.smallText = false;
    this.largeText = false;
    this.normalChoice = false;
    this.imageChoice = false;
    this.yesNo = false;
    this.radio = false;

    this.addOptionRemove = true;
    this.surveyCreationCompleted = false;
    this.enableNext = false;

    // this.surveyForm.valueChanges.subscribe(() => {
    //   console.log(this.surveyForm.value);
    // });
  }

  back() {
    this.surveyFormSubmit = false;
    this.enableNext = true;
  }

  next() {
    this.surveyFormSubmit = true;
    this.enableNext = false;
  }
  createSurvey() {
    this.survey.surveyName = this.surveyForm.controls.surveyName.value;
    this.survey.description = this.surveyForm.controls.description.value;
    this.surveyFormSubmit = true;
    this.addQuestion();
    // send it to api then process
  }

  addQuestion() {
    this.questionArray.push(this.createQuestion());
    if (this.questionArray.length == 0) {
      this.addQuestionRemove = true;
    } else {
      this.addQuestionRemove = false;
    }
  }

  removeQuestion(i) {
    this.questionArray.removeAt(i);
    if (this.questionArray.length == 0) {
      this.addQuestionRemove = true;
    } else {
      this.addQuestionRemove = false;
    }
  }

  createQuestion() {
    return this.formBuilder.group({
      questionName: ["", Validators.required],
      questionType: ["", Validators.required],
      options: this.formBuilder.array([])
    });
  }
  get questionArray() {
    return this.surveyForm.controls.questions as FormArray;
  }

  nextQuestion(i) {
    let question: any = {};
    let options: any[] = [];

    const optionArray = this.questionArray.controls[i].get(
      "options"
    ) as FormArray;

    question.questionName = this.questionArray.controls[i].get(
      "questionName"
    ).value;
    question.questionType = this.questionArray.controls[i].get(
      "questionType"
    ).value;
    if (
      this.questionArray.controls[i].get("questionName").value == "normalChoice"
    ) {
      for (let option of optionArray.controls) {
        options.push(option.value.option);
      }
      question.options = options;
    }
    if (
      this.questionArray.controls[i].get("questionName").value == "imageChoice"
    ) {
      for (let option of optionArray.controls) {
        options.push(option.value.option);
      }
      question.options = options;
    }
    if (this.questionArray.controls[i].get("questionName").value == "radio") {
      for (let option of optionArray.controls) {
        options.push(option.value.option);
      }
      question.options = options;
    }
    if (this.questionArray.controls[i].get("questionName").value == "yesNo") {
      options.push("Yes");
      options.push("No");
      question.options = options;
    }
    this.questions.push(question);
    this.addQuestion();

    this.addOptionRemove = true;

    this.smallText = false;
    this.largeText = false;
    this.normalChoice = false;
    this.imageChoice = false;
    this.yesNo = false;
    this.radio = false;
    // console.log(this.surveyForm);
  }

  createOption() {
    return this.formBuilder.group({
      option: ["", Validators.required],
      optionImage: [null]
    });
  }

  getOptions(form) {
    return form.controls.options.controls;
  }

  addOption(i) {
    const control = this.questionArray.controls[i].get("options") as FormArray;
    control.push(this.createOption());
    if (control.length == 0) {
      this.addOptionRemove = true;
    } else {
      this.addOptionRemove = false;
    }
  }

  removeOption(i, j) {
    const control = this.questionArray.controls[i].get("options") as FormArray;
    control.removeAt(j);
    if (control.length == 0) {
      this.addOptionRemove = true;
    } else {
      this.addOptionRemove = false;
    }
  }

  onChangeType(e) {
    switch (e.target.value) {
      case "smallText":
        this.smallText = true;
        this.largeText = false;
        this.normalChoice = false;
        this.imageChoice = false;
        this.yesNo = false;
        this.radio = false;
        break;
      case "largeText":
        this.smallText = false;
        this.largeText = true;
        this.normalChoice = false;
        this.imageChoice = false;
        this.yesNo = false;
        this.radio = false;
        break;
      case "normalChoice":
        this.smallText = false;
        this.largeText = false;
        this.normalChoice = true;
        this.imageChoice = false;
        this.yesNo = false;
        this.radio = false;
        break;
      case "imageChoice":
        this.smallText = false;
        this.largeText = false;
        this.normalChoice = false;
        this.imageChoice = true;
        this.yesNo = false;
        this.radio = false;
        break;
      case "yesNo":
        this.smallText = false;
        this.largeText = false;
        this.normalChoice = false;
        this.imageChoice = false;
        this.yesNo = true;
        this.radio = false;
        break;
      case "radio":
        this.smallText = false;
        this.largeText = false;
        this.normalChoice = false;
        this.imageChoice = false;
        this.yesNo = false;
        this.radio = true;
        break;
      default:
        this.smallText = false;
        this.largeText = false;
        this.normalChoice = false;
        this.imageChoice = false;
        this.yesNo = false;
        this.radio = false;
        break;
    }
    // console.log(
    //   this.smallText,
    //   this.largeText,
    //   this.normalChoice,
    //   this.imageChoice,
    //   this.yesNo,
    //   this.radio
    // );
  }
  submitSurvey() {
    this.surveyCreationCompleted = true;
    let jsonobj = JSON.stringify(this.surveyForm.value);
    console.log(jsonobj);
  }

  onSelectFile(event, i, j) {
    this.fileName = "";
    console.log(event, i, j);
    let fileName = event.target.files[0].name;
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = event => {
        // called once readAsDataURL is completed
        const control = this.questionArray.controls[i].get(
          "options"
        ) as FormArray;
        control.controls[j].get("optionImage").setValue(event.target.result);
        // console.log(this.questionArray.controls[i].get("options").value[j].optionImage);
        this.fileName = fileName;
      };
    }
  }
}
