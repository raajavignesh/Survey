import { Component, OnInit, Input, Output } from "@angular/core";
import { FormGroup, FormControl, FormArray } from "@angular/forms";

@Component({
  selector: "app-dynamic-form-builder",
  templateUrl: "./dynamic-form-builder.component.html",
  styleUrls: ["./dynamic-form-builder.component.css"]
})
export class DynamicFormBuilderComponent implements OnInit {
  @Input() surveyFormValue: any = {};
  questionsArray: FormArray;
  showFieldBuilder: boolean;

  constructor() {}

  ngOnInit(): void {
    this.showFieldBuilder = false;
    this.surveyFormValue.valueChanges.subscribe(e => {
      const questionArray = this.surveyFormValue.controls.questions;
      if (questionArray.length != 0) {
        this.questionsArray = questionArray;
      }
    });
  }

  takeSurvey() {
    this.showFieldBuilder = true;
  }
}
