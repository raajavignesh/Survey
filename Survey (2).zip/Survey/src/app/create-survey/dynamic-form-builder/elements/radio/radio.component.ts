import { Component, OnInit, Input } from "@angular/core";
import { FormArray } from "@angular/forms";

@Component({
  selector: "app-radio",
  templateUrl: "./radio.component.html",
  styleUrls: ["./radio.component.css"]
})
export class RadioComponent implements OnInit {
  @Input() question: any;
  @Input() i: any;
  fg: any;
  constructor() {}

  ngOnInit(): void {
    this.fg = "Q" + this.i;
  }
  get optionsArray() {
    return this.question.controls.options as FormArray;
  }
}
