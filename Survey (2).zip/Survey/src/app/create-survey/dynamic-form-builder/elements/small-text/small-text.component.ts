import { Component, OnInit, Input } from "@angular/core";

@Component({
  selector: "app-small-text",
  templateUrl: "./small-text.component.html",
  styleUrls: ["./small-text.component.css"]
})
export class SmallTextComponent implements OnInit {
  @Input() question;
  @Input() i: any;
  constructor() {}

  ngOnInit(): void {}
}
