import { Component, OnInit, Input } from "@angular/core";
import { FormGroup, FormControl, FormArray } from "@angular/forms";

@Component({
  selector: "app-feild-builder",
  templateUrl: "./feild-builder.component.html",
  styleUrls: ["./feild-builder.component.css"]
})
export class FeildBuilderComponent implements OnInit {
  @Input() questionsArray;

  constructor() {}

  ngOnInit(): void {}
}
