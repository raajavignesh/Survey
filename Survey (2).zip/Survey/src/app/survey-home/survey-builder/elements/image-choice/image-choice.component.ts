import { Component, OnInit, Input } from "@angular/core";
import { FormArray } from "@angular/forms";

@Component({
  selector: "app-image-choice",
  templateUrl: "./image-choice.component.html",
  styleUrls: ["./image-choice.component.css"]
})
export class ImageChoiceComponent implements OnInit {
  @Input() question: any;
  constructor() {}

  ngOnInit(): void {}

  get optionsArray() {
    return this.question.options;
  }
}
