import { Component, OnInit, Input } from "@angular/core";
import { FormArray } from "@angular/forms";

@Component({
  selector: "app-normal-choice",
  templateUrl: "./normal-choice.component.html",
  styleUrls: ["./normal-choice.component.css"]
})
export class NormalChoiceComponent implements OnInit {
  @Input() question: any;
  constructor() {}

  ngOnInit(): void {}

  get optionsArray() {
    return this.question.options;
  }
}
