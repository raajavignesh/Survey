import { Component, OnInit, Input } from "@angular/core";
import { FormBuilder } from "@angular/forms";

@Component({
  selector: "app-yes-no",
  templateUrl: "./yes-no.component.html",
  styleUrls: ["./yes-no.component.css"]
})
export class YesNoComponent implements OnInit {
  @Input() question: any;
  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {}

  get optionsArray() {
    return this.question.options;
  }
}
