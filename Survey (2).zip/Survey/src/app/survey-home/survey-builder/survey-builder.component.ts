import { Component, OnInit, Input } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";

@Component({
  selector: "app-survey-builder",
  templateUrl: "./survey-builder.component.html",
  styleUrls: ["./survey-builder.component.css"]
})
export class SurveyBuilderComponent implements OnInit {
  @Input() questions: any = {};
  survey1: FormGroup;
  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    console.log(this.questions);
    this.survey1 = this.formBuilder.group({});
    this.survey1.valueChanges.subscribe(() => {
      console.log(this.survey1.value);
    });
  }
}
