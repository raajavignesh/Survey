import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SurveyHomeComponent } from "./survey-home.component";
import { ReactiveFormsModule } from "@angular/forms";
import { SurveyBuilderComponent } from "./survey-builder/survey-builder.component";
import { SmallTextComponent } from "./survey-builder/elements/small-text/small-text.component";
import { LargeTextComponent } from "./survey-builder/elements/large-text/large-text.component";
import { NormalChoiceComponent } from "./survey-builder/elements/normal-choice/normal-choice.component";
import { ImageChoiceComponent } from "./survey-builder/elements/image-choice/image-choice.component";
import { YesNoComponent } from "./survey-builder/elements/yes-no/yes-no.component";
import { RadioComponent } from "./survey-builder/elements/radio/radio.component";

@NgModule({
  declarations: [
    SurveyHomeComponent,
    SurveyBuilderComponent,
    SmallTextComponent,
    LargeTextComponent,
    NormalChoiceComponent,
    ImageChoiceComponent,
    YesNoComponent,
    RadioComponent
  ],
  imports: [CommonModule, ReactiveFormsModule],
  exports: [SurveyHomeComponent]
})
export class SurveyHomeModule {}
