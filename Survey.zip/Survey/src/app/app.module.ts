import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { CreateSurveyModule } from "./create-survey/create-survey.module";
import { SurveyHomeModule } from "./survey-home/survey-home.module";
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    CreateSurveyModule,
    SurveyHomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
