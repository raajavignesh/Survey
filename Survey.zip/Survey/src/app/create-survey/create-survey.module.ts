import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule } from "@angular/forms";
import { CreateSurveyComponent } from "./create-survey.component";
import { DynamicFormBuilderModule } from "./dynamic-form-builder/dynamic-form-builder.module";

@NgModule({
  declarations: [CreateSurveyComponent],
  imports: [CommonModule, ReactiveFormsModule, DynamicFormBuilderModule],
  exports: [CreateSurveyComponent]
})
export class CreateSurveyModule {}
