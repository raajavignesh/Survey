import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule } from "@angular/forms";
import { DynamicFormBuilderComponent } from "./dynamic-form-builder.component";
import { FeildBuilderComponent } from "./feild-builder/feild-builder.component";
import { SmallTextComponent } from "./elements/small-text/small-text.component";
import { LargeTextComponent } from "./elements/large-text/large-text.component";
import { NormalChoiceComponent } from "./elements/normal-choice/normal-choice.component";
import { ImageChoiceComponent } from './elements/image-choice/image-choice.component';
import { RadioComponent } from './elements/radio/radio.component';
import { YesNoComponent } from './elements/yes-no/yes-no.component';

@NgModule({
  declarations: [
    DynamicFormBuilderComponent,
    FeildBuilderComponent,
    SmallTextComponent,
    LargeTextComponent,
    NormalChoiceComponent,
    ImageChoiceComponent,
    RadioComponent,
    YesNoComponent
  ],
  imports: [CommonModule, ReactiveFormsModule],
  exports: [DynamicFormBuilderComponent]
})
export class DynamicFormBuilderModule {}
