import { Component, OnInit, Input } from "@angular/core";

@Component({
  selector: "app-large-text",
  templateUrl: "./large-text.component.html",
  styleUrls: ["./large-text.component.css"]
})
export class LargeTextComponent implements OnInit {
  @Input() question;
  @Input() i: any;
  constructor() {}

  ngOnInit(): void {}
}
