import { Component, OnInit, Input } from "@angular/core";
import { FormArray, FormBuilder } from "@angular/forms";

@Component({
  selector: "app-yes-no",
  templateUrl: "./yes-no.component.html",
  styleUrls: ["./yes-no.component.css"]
})
export class YesNoComponent implements OnInit {
  @Input() question: any;
  @Input() i: any;
  fg: any;
  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.optionsArray.push(
      this.formBuilder.group({
        option: ["Yes"]
      })
    );
    this.optionsArray.push(
      this.formBuilder.group({
        option: ["No"]
      })
    );
    this.fg = "Q" + this.i;
  }

  get optionsArray() {
    return this.question.controls.options as FormArray;
  }
}
