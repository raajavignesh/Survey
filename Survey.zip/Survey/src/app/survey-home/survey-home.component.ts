import { Component, OnInit } from "@angular/core";


@Component({
  selector: "app-survey-home",
  templateUrl: "./survey-home.component.html",
  styleUrls: ["./survey-home.component.css"]
})
export class SurveyHomeComponent implements OnInit {
  surveyDump: any[];
  url;
  constructor() { }

  ngOnInit(): void {
    this.surveyDump = [
      {
        surveyName: "survey 1",
        description: "vxcvxcvxcvfsfdfsdf",
        questions: [
          { questionName: "sdfsdfsdf", questionType: "smallText", options: [] },
          { questionName: "sdfsdf", questionType: "largeText", options: [] },
          {
            questionName: "sdfxcvxvxv",
            questionType: "normalChoice",
            options: [
              { option: "qweqw" },
              { option: "xcvxv" },
              { option: "xcvcxvc" },
              { option: "xcvcvvv" }
            ]
          },
          {
            questionName: "cxvxcvxcv",
            questionType: "imageChoice",
            options: [
              { option: "cxvxcv" },
              { option: "qeqwe" },
              { option: "qweqwe" },
              { option: "ererer" }
            ]
          },
          {
            questionName: "ererfgfvgdfvdfd",
            questionType: "yesNo",
            options: [{ option: "Yes" }, { option: "No" }]
          },
          {
            questionName: "dfgdgdfgdfg",
            questionType: "radio",
            options: [
              { option: "dfcbcvb" },
              { option: "rtertr" },
              { option: "vbcb" },
              { option: "qweqeqeq" }
            ]
          }
        ]
      },
      {
        surveyName: "survey 2",
        description: "vxcvxcvxcvfsfdfsdf",
        questions: [
          { questionName: "sdfsdfsdf", questionType: "smallText", options: [] },
          { questionName: "sdfsdf", questionType: "largeText", options: [] },
          {
            questionName: "sdfxcvxvxv",
            questionType: "normalChoice",
            options: [
              { option: "qweqw" },
              { option: "xcvxv" },
              { option: "xcvcxvc" },
              { option: "xcvcvvv" }
            ]
          },
          {
            questionName: "cxvxcvxcv",
            questionType: "imageChoice",
            options: [
              { option: "cxvxcv" },
              { option: "qeqwe" },
              { option: "qweqwe" },
              { option: "ererer" }
            ]
          },
          {
            questionName: "ererfgfvgdfvdfd",
            questionType: "yesNo",
            options: [{ option: "Yes" }, { option: "No" }]
          },
          {
            questionName: "dfgdgdfgdfg",
            questionType: "radio",
            options: [
              { option: "dfcbcvb" },
              { option: "rtertr" },
              { option: "vbcb" },
              { option: "qweqeqeq" }
            ]
          }
        ]
      }
    ];
  }
  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        console.log(event.target.result);

        this.url = event.target.result;
      }
    }
  }
}
