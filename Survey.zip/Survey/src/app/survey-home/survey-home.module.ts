import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SurveyHomeComponent } from "./survey-home.component";
import { ReactiveFormsModule } from "@angular/forms";

@NgModule({
  declarations: [SurveyHomeComponent],
  imports: [CommonModule, ReactiveFormsModule],
  exports: [SurveyHomeComponent]
})
export class SurveyHomeModule {}
